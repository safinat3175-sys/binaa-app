"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Shell, Toast, useLang } from "@/components/BinaaShell";
import { T } from "@/lib/i18n";
import { SPECIALTIES } from "@/lib/specialties";
import { WILAYAS } from "@/lib/wilayas";

interface Me {
  id: string; name: string; role: string; wilaya: string | null; specialty: string | null;
  dailyWageExpectation: number | null; experienceYears: number | null; companyName: string | null;
  profileCompleted: boolean;
}

/**
 * Step 3 of onboarding — branches by role:
 *   worker     → Worker profile (specialty, wage, wilaya) → POST /api/profile
 *   contractor → CREATE PROJECT form                    → POST /api/contractor/onboard
 */
export default function CompleteProfilePage() {
  const [L, toggle] = useLang();
  const t = T[L];
  const router = useRouter();
  const [me, setMe] = useState<Me | null | undefined>(undefined);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/auth/me").then(async (r) => {
      if (!r.ok) { router.replace("/"); return; }
      const d = await r.json();
      if (d.user?.profileCompleted) { router.replace("/"); return; }
      setMe(d.user);
    }).catch(() => router.replace("/"));
  }, [router]);

  const done = () => { setToast("✅"); router.replace("/"); };

  return (
    <Shell L={L} toggle={toggle}>
      {me === undefined ? (
        <p className="binaa-mut">{t.loading}</p>
      ) : me && (
        <div className="binaa-anim">
          <div className="binaa-steps"><span className="on" /><span className="on" /><span className="on" /></div>
          {me.role === "contractor" ? <ContractorProjectForm L={L} me={me} onDone={done} /> : <WorkerProfileForm L={L} me={me} onDone={done} />}
        </div>
      )}
      <Toast msg={toast} />
    </Shell>
  );
}

/* ── shared pieces ── */
function Terms({ L }: { L: "ar" | "en" }) {
  const t = T[L];
  return (
    <details className="binaa-terms">
      <summary>{t.termsTitle}</summary>
      <ul style={{ paddingInlineStart: 18, margin: "6px 0" }}>
        <li>{L === "ar" ? "رقم هاتفك لا يُعرض لأي مستخدم على الموقع أو عبر البوت." : "Your phone number is never displayed to other users on the site or via the bot."}</li>
        <li>{L === "ar" ? "يُرسل رقمك فقط للطرف المقابل في مطابقة وافقت عليها الإدارة، عبر رسالة تيليغرام خاصة." : "Your number is sent only to the counter-party of a match approved by the admin, via a private Telegram message."}</li>
        <li>{L === "ar" ? "المنصة وسيط فقط ولا تتحمل مسؤولية الاتفاقات بين الطرفين." : "The platform is an intermediary only and is not party to agreements between users."}</li>
      </ul>
    </details>
  );
}
const SpecOptions = ({ L }: { L: "ar" | "en" }) => (
  <>{SPECIALTIES.map((s) => <option key={s.value} value={s.value}>{s.icon} {L === "ar" ? `${s.ar} (${s.fr})` : `${s.fr} (${s.ar})`}</option>)}</>
);
const WilOptions = ({ L }: { L: "ar" | "en" }) => (
  <>{WILAYAS.map((w) => <option key={w.code} value={w.code}>{w.code} · {L === "ar" ? w.ar : w.fr}</option>)}</>
);

/* ═══════════════════════ WORKER PROFILE ═══════════════════════ */
function WorkerProfileForm({ L, me, onDone }: { L: "ar" | "en"; me: Me; onDone: () => void }) {
  const t = T[L];
  const [f, setF] = useState({
    name: me.name ?? "", specialty: me.specialty ?? "ferrailleur", wilaya: me.wilaya ?? "16",
    dailyWageExpectation: me.dailyWageExpectation ? String(me.dailyWageExpectation) : "",
    experienceYears: String(me.experienceYears ?? 0), agreement: false,
  });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(null);
    if (!f.agreement) return setErr(t.mustAgree);
    if (!f.dailyWageExpectation || Number(f.dailyWageExpectation) < 500) return setErr(t.fill);
    setBusy(true);
    try {
      const r = await fetch("/api/profile", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...f, dailyWageExpectation: Number(f.dailyWageExpectation), experienceYears: Number(f.experienceYears) || 0 }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "error");
      onDone();
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : "error"); } finally { setBusy(false); }
  }

  return (
    <>
      {err && <p className="binaa-err">{err}</p>}
      <div className="binaa-card">
        <h3>👷 {t.completeTitle}</h3>
        <p className="binaa-mut" style={{ marginTop: 0 }}>{t.workerSub}</p>
        <form onSubmit={submit}>
          <label>{t.name}</label>
          <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <label>{t.spec}</label>
          <select value={f.specialty} onChange={(e) => setF({ ...f, specialty: e.target.value })}><SpecOptions L={L} /></select>
          <label>{t.wil}</label>
          <select value={f.wilaya} onChange={(e) => setF({ ...f, wilaya: e.target.value })}><WilOptions L={L} /></select>
          <div className="binaa-grid">
            <div><label>{t.wage}</label><input type="number" min={500} inputMode="numeric" dir="ltr" placeholder="3000" value={f.dailyWageExpectation} onChange={(e) => setF({ ...f, dailyWageExpectation: e.target.value })} /></div>
            <div><label>{t.exp}</label><input type="number" min={0} max={60} inputMode="numeric" dir="ltr" value={f.experienceYears} onChange={(e) => setF({ ...f, experienceYears: e.target.value })} /></div>
          </div>
          <Terms L={L} />
          <label className="binaa-check"><input type="checkbox" checked={f.agreement} onChange={(e) => setF({ ...f, agreement: e.target.checked })} /><span>{t.agree}</span></label>
          <button className="binaa-btn y full" disabled={busy || !f.agreement}>{busy ? "…" : t.submitApp}</button>
        </form>
      </div>
    </>
  );
}

/* ═══════════════════════ CONTRACTOR → CREATE PROJECT ═══════════════════════ */
function ContractorProjectForm({ L, me, onDone }: { L: "ar" | "en"; me: Me; onDone: () => void }) {
  const t = T[L];
  const [f, setF] = useState({
    companyName: me.companyName ?? "", title: "", wilaya: me.wilaya ?? "16", specialty: "macon",
    workersNeeded: "1", dailyWage: "", description: "", agreement: false,
  });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(null);
    if (!f.agreement) return setErr(t.mustAgree);
    if (f.title.trim().length < 3 || !f.dailyWage || !f.workersNeeded) return setErr(t.fill);
    setBusy(true);
    try {
      const r = await fetch("/api/contractor/onboard", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...f, workersNeeded: Number(f.workersNeeded), dailyWage: Number(f.dailyWage) }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "error");
      onDone();
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : "error"); } finally { setBusy(false); }
  }

  return (
    <>
      {err && <p className="binaa-err">{err}</p>}
      <div className="binaa-card">
        <h3>🏗️ {t.createProject}</h3>
        <p className="binaa-mut" style={{ marginTop: 0 }}>{t.createProjectSub}</p>
        <form onSubmit={submit}>
          <label>{t.company}</label>
          <input value={f.companyName} onChange={(e) => setF({ ...f, companyName: e.target.value })} placeholder={me.name} />

          <label>{t.title} *</label>
          <input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder={L === "ar" ? "مثال: بناء فيلا R+1 في المسيلة" : "e.g. Villa R+1 in M'Sila"} />

          <label>{t.wil} *</label>
          <select value={f.wilaya} onChange={(e) => setF({ ...f, wilaya: e.target.value })}><WilOptions L={L} /></select>

          <label>{t.reqSpec} *</label>
          <select value={f.specialty} onChange={(e) => setF({ ...f, specialty: e.target.value })}><SpecOptions L={L} /></select>

          <div className="binaa-grid">
            <div><label>{t.need} *</label><input type="number" min={1} max={500} inputMode="numeric" dir="ltr" value={f.workersNeeded} onChange={(e) => setF({ ...f, workersNeeded: e.target.value })} /></div>
            <div><label>{t.dailyWage} *</label><input type="number" min={500} inputMode="numeric" dir="ltr" placeholder="3500" value={f.dailyWage} onChange={(e) => setF({ ...f, dailyWage: e.target.value })} /></div>
          </div>

          <label>{t.details}</label>
          <textarea className="binaa-input binaa-textarea" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />

          <Terms L={L} />
          <label className="binaa-check"><input type="checkbox" checked={f.agreement} onChange={(e) => setF({ ...f, agreement: e.target.checked })} /><span>{t.agree}</span></label>
          <button className="binaa-btn y full" disabled={busy || !f.agreement}>{busy ? "…" : t.publishProject}</button>
          <p className="binaa-note">{t.matchHint}</p>
        </form>
      </div>
    </>
  );
}
