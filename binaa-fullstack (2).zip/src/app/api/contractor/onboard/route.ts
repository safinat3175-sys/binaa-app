import { db } from "@/db";
import { projects, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getUserFromRequest, publicSelf } from "@/lib/auth";
import { SPECIALTIES } from "@/lib/specialties";
import { WILAYAS } from "@/lib/wilayas";

export const dynamic = "force-dynamic";

/**
 * CONTRACTOR onboarding = "Create Project" (NOT the worker profile form).
 *
 * Body: {
 *   title, wilaya, specialty, workersNeeded, dailyWage,   // project (required)
 *   companyName?, description?, agreement: true           // profile bits
 * }
 *
 * Atomically:
 *   1. marks the contractor profile completed (+ agreement, company name, wilaya)
 *   2. inserts the first row in `projects` linked to contractor_id = session user
 */
export async function POST(req: Request) {
  const me = await getUserFromRequest(req);
  if (!me) return Response.json({ error: "Unauthorized" }, { status: 401 });
  if (me.role !== "contractor") return Response.json({ error: "هذه الخطوة للمقاولين فقط" }, { status: 403 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const title = String(body.title ?? "").trim().slice(0, 255);
  const wilaya = String(body.wilaya ?? "").trim();
  const specialty = String(body.specialty ?? "").trim();
  const workersNeeded = Math.round(Number(body.workersNeeded ?? 0));
  const dailyWage = Math.round(Number(body.dailyWage ?? 0));
  const companyName = String(body.companyName ?? "").trim().slice(0, 255);
  const description = String(body.description ?? "").trim().slice(0, 1000);
  const agreement = body.agreement === true;

  if (!agreement) return Response.json({ error: "يجب الموافقة على الشروط والأحكام" }, { status: 400 });
  if (title.length < 3) return Response.json({ error: "عنوان المشروع مطلوب" }, { status: 400 });
  if (!WILAYAS.some((w) => w.code === wilaya)) return Response.json({ error: "اختر الولاية" }, { status: 400 });
  if (!SPECIALTIES.some((s) => s.value === specialty)) return Response.json({ error: "اختر التخصص المطلوب" }, { status: 400 });
  if (!Number.isFinite(workersNeeded) || workersNeeded < 1 || workersNeeded > 500)
    return Response.json({ error: "العدد المطلوب يجب أن يكون بين 1 و 500" }, { status: 400 });
  if (!Number.isFinite(dailyWage) || dailyWage < 500 || dailyWage > 100000)
    return Response.json({ error: "الأجر اليومي يجب أن يكون 500 دج على الأقل" }, { status: 400 });

  const result = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(users)
      .set({
        wilaya,
        companyName: companyName || me.companyName || null,
        agreementAccepted: true,
        agreementAcceptedAt: me.agreementAcceptedAt ?? new Date(),
        profileCompleted: true,
      })
      .where(eq(users.id, me.id))
      .returning();

    const [project] = await tx
      .insert(projects)
      .values({
        contractorId: me.id,
        title,
        wilaya,
        specialty,
        workersNeeded,
        dailyWage,
        description: description || null,
        status: "open",
      })
      .returning();

    return { updated, project };
  });

  return Response.json({ ok: true, user: publicSelf(result.updated), project: result.project }, { status: 201 });
}
